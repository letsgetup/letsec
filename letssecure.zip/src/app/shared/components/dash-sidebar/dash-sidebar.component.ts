import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dash-sidebar',
  templateUrl: './dash-sidebar.component.html'
})
export class DashSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
