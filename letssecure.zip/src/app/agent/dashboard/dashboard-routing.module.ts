import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '@app/_helpers';
import { AgentModule } from '../agent.module';
import { DashboardComponent } from './dashboard.component';
import { DashboardModule } from './dashboard.module';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
  {
    path: '', component: DashboardComponent,
    children: [
      { path: 'dashboard/welcome', component: WelcomeComponent ,canActivate: [AuthGuard] },
      { path: 'dashboard/edit', component: EditProfileComponent ,canActivate: [AuthGuard] }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
