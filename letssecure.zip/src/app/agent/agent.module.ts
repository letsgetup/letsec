import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AgentRoutingModule } from './agent-routing.module';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LayoutComponent } from './layout.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SharedModule } from '@app/shared/shared.module';
import { EditProfileComponent } from './dashboard/edit-profile/edit-profile.component';
import { DashboardModule } from './dashboard/dashboard.module';


@NgModule({
  declarations: [
    LayoutComponent,
    LoginComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    AgentRoutingModule,
    NgbModule,
    SharedModule,
    DashboardModule
    
  ]
})
export class AgentModule { }
