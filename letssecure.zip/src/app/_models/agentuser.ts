﻿export class AgentUser {
    agentid: string;
    email: string;
    mobile: string;
    pancard: string;
}