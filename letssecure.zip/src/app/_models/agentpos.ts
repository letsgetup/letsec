﻿export class AgentPos {
    id: string;
    fullname: string;
    mobile: string;
    pincode: string;
}