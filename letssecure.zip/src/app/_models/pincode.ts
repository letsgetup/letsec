﻿export class PincodeM {
    PostOfficeName: string;
Pincode: string;
City: string;
District: string;
State:string;

}